class A
	def initialize
		$global_variable ||=10
		@@class_variable ||=10
		@instance_variable ||=10
		local_variable ||=10
	end
	def method
		$global_variable +=10
		@@class_variable +=10
		@instance_variable +=10
	        p "#{$global_variable}"
		p "#{@@class_variable}"
		p "#{@instance_variable}"
	end
end
class B
	def initialize
		$global_variable ||=10
		@@class_variable ||=10
		@instance_variable ||=10
		local_variable ||=10
	end
	def method
		$global_variable +=10
		@@class_variable +=10
		@instance_variable +=10
	        p "#{$global_variable}"
		p "#{@@class_variable}"
		p "#{@instance_variable}"
	end
end
a=A.new
a.method
b=A.new
b.method
c=B.new
c.method
