a=34
b=06
c=34
p "this is line 1 of single execution" if a>b
p "this is line 2 of single execution" if a<b
p "this is line 3 of single execution" if a=c
