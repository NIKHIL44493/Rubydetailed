$gb=6
	module Module1
		p "inside module1"
		p $gb
	end
	def method1
		p "inside method1"
		p $gb
	end
	class Some
		p "inside class"
		p $gb
	end
	method1
	p "inside toplevel"
	p $gb
	p global_variable.include?  $gb
