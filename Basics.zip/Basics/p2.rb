a=10
b=20
p "before swapping a=#{a} b=#{b}"
a,b = b,a
p "after swapping a=#{a} b=#{b}"
c=10
d=20
e=30
p "before swapping c=#{c} d=#{d} e=#{e}"
c,d,e = d,e,c
p "before swapping c=#{c} d=#{d} e=#{e}"
k="hi3"
l="hello4"
p "before swapping k=#{k} l=#{l}"
k,l=l,k

p "after swapping k=#{k} l=#{l}"

