class Admin < ApplicationRecord
end
